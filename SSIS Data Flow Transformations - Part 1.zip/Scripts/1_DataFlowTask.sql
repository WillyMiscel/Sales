/*============================================================================================
 Copyright (C) 2016 SQLMaestros.com | eDominer Systems P Ltd.
  All rights reserved.
    
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.

=============================================================================================*/
-------------------------------------------------------
-- Lab: SSIS Data Transformation Part 1
-------------------------------------------------------
---------------
--BEGIN SETUP
---------------
USE master
GO
IF  EXISTS (
	SELECT name 
		FROM sys.databases 
		WHERE name = N'SQLMaestros'
)
DROP DATABASE SQLMaestros
GO
CREATE DATABASE SQLMaestros
GO
---------------
--END SETUP
---------------

--Step 1: fetch the records from the destination table
USE SQLMaestros
GO
SELECT * 
FROM dbo.[Person.Address]
GO


--Step 2: Query for first look up. Copy and paste this query in the lookup transformation as mentioned in the lab document
USE AdventureWorks2014
SELECT ProductID, Name FROM Production.Product

--Step3: Query for second look up. Copy and paste this query in the lookup transformation as mentioned in the lab document
USE AdventureWorks2014
SELECT TerritoryID, Name FROM Sales.SalesTerritory


--Step 4: Fetch the records from both the destination tables
USE SQLMaestros
GO
SELECT * FROM [dbo].[SalesDetails_NorthAmerica]
GO
SELECT * FROM [dbo].[SalesDetails_Others]
GO


/*===================================================================================================
For Hands-On-Labs feedback, write to us at holfeedback@SQLMaestros.com
For Hands-On-Labs support, write to us at holsupport@SQLMaestros.com
Do you wish to subscribe to HOLs for your team? Email holsales@SQLMaestros.com
For SQLMaestros Master Classes & Videos, visit www.SQLMaestros.com
====================================================================================================*/